import React from 'react'
import { Container } from 'react-bootstrap'
import Sidebar from './../../Components/CarConnectSideBar/Sidebar'
import { Row, Col } from 'react-bootstrap';
import car1 from './../../Assets/Images/car1.png'
import red from './../../Assets/Images/car2.png'
import AddIcon from '@mui/icons-material/Add';
import Button from './../../Components/Button/Button'

const CreateClubs = () => {
  return (
    <div>
        <Sidebar />
        <Container className='full'>
          <div className="area">
            <h2>Create your club</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae ex, sunt harum blanditiis modi corporis?</p>
          </div>
          <Row>
            <Col className='first' md>
              <label>Name</label>  <br />
              <input className='inputs' type="Text" placeholder='Enter Your Name'/>
            </Col>
            <Col md>
              <label>Location</label>  <br />
              <input className='inputs' type="Text" placeholder='CodeCue Software House'/>
            </Col>
            <Col md>
              <label>Description</label>  <br />
              <input className='inputs' type="Text" placeholder='Car Description'/>
            </Col>
          </Row>
          <Row>
            <Col className='last' md>
              <label>Club Privacy</label>  <br />
              <select>
                <option>Select  Private or Share</option>
                <option>Private</option>
                <option>Shared</option>
              </select>
            </Col>
          </Row>

          <div className="image">
            <img src={red} alt="" />
            <img className='two' src={car1} alt="" />
            <button type='file' id="myfile" name="myfile" className='btn'><AddIcon /><br /> Add More</button>
          </div>

          <Button />
        </Container>


    </div>
  )
}

export default CreateClubs