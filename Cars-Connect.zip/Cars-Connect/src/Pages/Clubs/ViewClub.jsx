import React from 'react'
import { Container, Row, Col } from 'react-bootstrap';
import Sidebar from './../../Components/CarConnectSideBar/Sidebar'
import yellow from '../../Assets/Images/yellow.png'
import StarIcon from '@mui/icons-material/Star';
import LockIcon from '@mui/icons-material/Lock';
import group from './../../Assets/Images/group.png'
import map from './../../Assets/Images/map.png'
import "./style.css"

const ViewClub = () => {
  return (
    <div>
      <Sidebar />
      <Container className='con'>
        <div className="txt">
          <img className='car' src={yellow} alt="" />
          <h4>Ace Classic Club</h4>
          <div className="stars">
            <StarIcon className='star' />
            <StarIcon className='star' />
            <StarIcon className='star' />
            <StarIcon className='star' />
            <StarIcon className='star' /> &nbsp;
            5.0
          </div>

          <span className='lock'><LockIcon /> Private Club</span>
          <br />

          <img className='group2' src={group} alt="" /><span>&nbsp; 2.5 k total members</span>

            <br />
            <br />
          <h5>Description</h5>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eum harum quisquam sunt consequuntur et. Dolores eligendi cumque tempore delectus blanditiis numquam consectetur, exercitationem deserunt provident, recusandae quibusdam, laborum impedit consequuntur!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione perferendis in sapiente tempore praesentium at a error, autem impedit assumenda quia laudantium voluptates saepe placeat! Autem optio recusandae a nulla?
          </p>

          <br />
          <br />
          <br />

          <h5>Location</h5>
          <img className='car' src={map} alt="" />
          <br />
          <br />
        </div>

      </Container>
    </div>
  )
}

export default ViewClub