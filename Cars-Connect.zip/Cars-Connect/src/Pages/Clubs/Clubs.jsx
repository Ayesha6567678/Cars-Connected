import { Container } from '@mui/system'
import React from 'react'
import Sidebar from './../../Components/CarConnectSideBar/Sidebar'
import { Row, Col } from 'react-bootstrap';
import image from "../../Assets/Images/img.png"
import './style.css'
import group from './../../Assets/Images/group.png'
import UpdateIcon from '@mui/icons-material/Update';

const clubs = () => {
  return (
    <div>
        <Sidebar />

        <Container className="flow">
            <Row className='row'>
            <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                    </div>
            </Col>
            <Col md>
                <div className="all">
                <input type="checkbox" value="check"/>
                    <div className='box'>
                        <img src={image} alt="img" />
                        <div className="txt">
                            <h6>Ace Classic Club</h6>
                            <p><img className='group' src={group} alt="group" /> +120</p>
                            <span><UpdateIcon /> July 10,2021</span>
                        </div>
                    </div>
                </div>
            </Col>
            <Col md>
                <div className="all">
                <input type="checkbox" value="check"/>
                    <div className='box'>
                        <img src={image} alt="img" />
                        <div className="txt">
                            <h6>Ace Classic Club</h6>
                            <p><img className='group' src={group} alt="group" /> +120</p>
                            <span><UpdateIcon /> July 10,2021</span>
                        </div>
                    </div>
                </div>
            </Col>

            </Row>
            <Row className='row'>
            <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                    </div>
            </Col>
            <Col md>
                <div className="all">
                <input type="checkbox" value="check"/>
                    <div className='box'>
                        <img src={image} alt="img" />
                        <div className="txt">
                            <h6>Ace Classic Club</h6>
                            <p><img className='group' src={group} alt="group" /> +120</p>
                            <span><UpdateIcon /> July 10,2021</span>
                        </div>
                    </div>
                </div>
            </Col>
            <Col md>
                <div className="all">
                <input type="checkbox" value="check"/>
                    <div className='box'>
                        <img src={image} alt="img" />
                        <div className="txt">
                            <h6>Ace Classic Club</h6>
                            <p><img className='group' src={group} alt="group" /> +120</p>
                            <span><UpdateIcon /> July 10,2021</span>
                        </div>
                    </div>
                </div>
            </Col>

            </Row>
            <Row className='row'>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                        </div>
                </Col>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                            <div className='box'>
                                <img src={image} alt="img" />
                                <div className="txt">
                                    <h6>Ace Classic Club</h6>
                                    <p><img className='group' src={group} alt="group" /> +120</p>
                                    <span><UpdateIcon /> July 10,2021</span>
                                </div>
                        </div>
                    </div>
                </Col>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                    </div>
                </Col>

            </Row>
            <Row className='row'>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                        </div>
                </Col>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                            <div className='box'>
                                <img src={image} alt="img" />
                                <div className="txt">
                                    <h6>Ace Classic Club</h6>
                                    <p><img className='group' src={group} alt="group" /> +120</p>
                                    <span><UpdateIcon /> July 10,2021</span>
                                </div>
                        </div>
                    </div>
                </Col>
                <Col md>
                    <div className="all">
                    <input type="checkbox" value="check"/>
                        <div className='box'>
                            <img src={image} alt="img" />
                            <div className="txt">
                                <h6>Ace Classic Club</h6>
                                <p><img className='group' src={group} alt="group" /> +120</p>
                                <span><UpdateIcon /> July 10,2021</span>
                            </div>
                        </div>
                    </div>
                </Col>

            </Row>
        </Container>
    </div>
  )
}

export default clubs