import React from 'react'
import  "./Style.css"
import Sidebar from '../../Components/CarConnectSideBar/Sidebar'
import { Col, Container, Row } from 'react-bootstrap';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import Badge from 'react-bootstrap/Badge';
import  Slider from './../../Components/slider/Slider';

const Details = () => {
  return (
    <>
      <Sidebar />
      <div className="details">
        <Container>
          <Row>
            <Col md className='Heding'>
                <h4>Honda Civic Turbo 1.6</h4>
                <p><span className='cars'>Cars Connected <ArrowForwardIcon />  Users <ArrowForwardIcon /> Garage <ArrowForwardIcon /></span>Honda Civic Turbo 1.6  </p>
            </Col>
            <Col md>
              <Row>
                <Col lg>
                <Badge className='piiled' pill bg="dark">
                  UnBlock Users
                </Badge>
                </Col>
                <Col lg>
                <Badge className='piiled' pill bg="dark">
                  Blocked Users
                </Badge>
                </Col>
                <Col lg>
                <Badge className='piiled' pill bg="dark">
                  Active Users
                </Badge>
                </Col>
              </Row>
              
            </Col>
          </Row>
          <Slider />
          <div className="bottom">
            <p>Specification</p>
          </div>
          <Row className='bot'>
            <Col className='txt' md>
                <p>Brand</p>
                <h3>Honda</h3>
            </Col>
            <Col className='txt' md>
                <p>Model</p>
                <h3>Insights</h3>
            </Col>
            <Col className='txt' md>
                <p>Year</p>
                <h3>2013</h3>
            </Col>
          </Row>
          <Row className='bot'>
            <Col className='txt' md>
                <p>Engine</p>
                <h3>1598</h3>
            </Col>
            <Col className='txt' md>
                <p>Type</p>
                <h3>Sports</h3>
            </Col>
            <Col className='txt' md>
                <p>Color</p>
                <h3>White</h3>
            </Col>
          </Row>

          <div className="bottom">
            <p>Description:</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus, tempore necessitatibus repudiandae vitae eum deleniti? Hic explicabo sequi provident tempore voluptatibus quam dolorum officia, perspiciatis illo facilis animi debitis eligendi?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tempore veritatis non doloremque, voluptates dolor ut iusto asperiores quis repudiandae impedit omnis voluptas! Eaque, quam? Itaque perferendis atque quis at dolorem.</p>
          </div>
        </Container>


      </div>
    </>
  )
}

export default Details