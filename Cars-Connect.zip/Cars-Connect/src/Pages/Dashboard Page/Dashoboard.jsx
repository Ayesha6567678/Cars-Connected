import React from 'react'
import Sidebar from './../../Components/CarConnectSideBar/Sidebar'
import './style.css'
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { Row, Col } from 'react-bootstrap';
import chart from './../../Assets/Images/chart.png'
import usr from "../../Assets/Images/usr.png"
import group from "../../Assets/Images/group.png"
import { Container } from '@mui/system';

const Dashoboard = () => {
  return (
    <>
        <Sidebar />

        <div className="text_section">
        <h3>Dashoboard</h3>
        <p><span className='cars'>Cars Connected <ArrowForwardIcon /> </span> Users</p>
        
        </div>
      <Container>
        <div className="box">
        <Row>
            <Col className='rect re' sm>
                <p className='p'>Users</p>
                <h2 className='h3'>65K</h2>
            </Col>
            <Col className='rect' sm>
                <p className='p'>Clubs</p>
                <h2 className='h3'>65K</h2>
            </Col>
            <Col className='rect' sm>
                <p className='p'>Events</p>
                <h2 className='h3'>65K</h2>
            </Col>
            <Col className='rect four' sm>
                <p className='p'>Item listed</p>
                <h2 className='h3'>65K</h2>
            </Col>
        </Row>

        <center><img className='chart' src={chart} alt="chart" /></center>
        </div>

        <div className="users">
          <Row>
            <Col xl>
              <div className="usrs">
              <b><p className='h5'>Active Events</p></b>
              <p className='para'>Today</p>

                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022</p>
                <hr />
                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022</p>
                <hr />
                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022</p>
              </div>
            </Col>
            <Col xl>
              <div className="usrs">
              <p className='h5'>Active Events</p>
              <p className='para'>Today</p>

                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022 <br />
                <img className='Group' src={group} alt="grou" />
                </p>
                <hr />
                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022 <br />
                <img className='Group' src={group} alt="grou" />
                </p>
                <hr />
                <p><img className='usr' src={usr} alt="usr" /> &nbsp; Car Show 20022 <br />
                <img className='Group' src={group} alt="grou" />
                </p>
                </div>
            </Col>
          </Row>
        </div>
      </Container>


    </>
  )
}

export default Dashoboard