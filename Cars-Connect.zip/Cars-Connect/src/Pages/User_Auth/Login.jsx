import React from 'react'
import { Row, Col } from 'react-bootstrap'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import "./Style.css"
import logo from "../../Assets/Images/logo.png"
import car from "../../Assets/Images/car.png"


const Login = () => {
  return (
    <>
        <Row>
            <Col className='From_Section' xl>
                <div className="section">
                    <Form className='form'>
                        <center>
                            <h3>Welcome Back</h3>
                            <p>Please Enter You Login Deatils</p>
                        </center>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label className='label'>Email address</Form.Label>
                        <Form.Control className='input' type="email" placeholder="Enter email" />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label className='label'>Password</Form.Label>
                        <Form.Control className='input' type="password" placeholder="Password" />
                    </Form.Group>
                    <Button variant="primary" type="submit" className="rounded-pill">
                        Submit
                    </Button>
                    </Form>
                </div>
            </Col>
            <Col xl>
                <div className="image_section">
                    <img className='car' src={car} alt="car" />
                    <center><img className='logo' src={logo} alt="logo" /></center>
                </div>
            </Col>
        </Row>
    </>
  )
}

export default Login