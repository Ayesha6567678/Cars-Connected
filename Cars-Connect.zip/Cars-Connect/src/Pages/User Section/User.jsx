import React from 'react'
import Sidebar from '../../Components/CarConnectSideBar/Sidebar'
import { Col, Container, Row } from 'react-bootstrap';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import Badge from 'react-bootstrap/Badge';
import Table from './../../Components/table/Table'
import "./Style.css"

const Details = () => {
  return (
    <>
      <Sidebar />
      <Container>
        <div className="details">
          <Row>
            <Col md className='Heding'>
                <h4>Users</h4>
                <p><span className='cars'>Cars Connected <ArrowForwardIcon />  </span> Users  </p>
            </Col>
            <Col md>
              <Row>
                <Col lg>
                  <Badge className='piiled warn' pill bg="none">Filter
                  </Badge>
                </Col>
                <Col lg>
                  <Badge className='piiled' pill bg="dark">
                    UnBlock Users
                  </Badge>
                </Col>
                <Col lg>
                <Badge className='piiled' pill bg="dark">
                  Blocked Users
                </Badge>
                </Col>
                <Col lg>
                <Badge className='piiled' pill bg="dark">
                  Active Users
                </Badge>
                </Col>
              </Row>
              
            </Col>
          </Row>
        </div>

        <Table />
      </Container>
    </>
  )
}

export default Details