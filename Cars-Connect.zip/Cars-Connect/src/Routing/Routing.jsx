import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './../Pages/User_Auth/Login';
import Dashoboard from './../Pages/Dashboard Page/Dashoboard';
import Details from './../Pages/ViewDetails/Details';
import User from './../Pages/User Section/User'
import Clubs from './../Pages/Clubs/Clubs';
import CreateClubs from './../Pages/Clubs/CreateClubs';
import ViewClub from './../Pages/Clubs/ViewClub';
import EditClub from './../Pages/Clubs/EditClub';

const Routing = () => {
  return (
    <div>
        <BrowserRouter>
        <Routes>
          <Route exact path="/" element={<Login />} />
          <Route exact path="/Dashboard" element={<Dashoboard />} />
          <Route exact path="/Details" element={<Details />} />
          <Route exact path="/User" element={<User />} />
          <Route exact path="/Clubs" element={<Clubs />} />
          <Route exact path="/Create-clubs" element={<CreateClubs />} />
          <Route exact path="/ViewClubs" element={<ViewClub />} />
          <Route exact path="/EditClubs" element={<EditClub />} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default Routing