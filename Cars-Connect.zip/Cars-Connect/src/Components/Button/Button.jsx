import React from 'react'
import './style.css'

const button = () => {
  return (
    <div>
        <center><button className='design'>Save & Continue</button></center>
    </div>
  )
}

export default button